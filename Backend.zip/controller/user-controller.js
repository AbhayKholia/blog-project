import User from '../model/user.js'
import bcrypt from 'bcrypt'

 const signupUser = async (request , res) =>{
 try{
    const hashpassword = await bcrypt.hash(request.body.password , 10)


    const user = {username:request.body.username, name:request.body.name, password:hashpassword};


    const newUser = new User(user)
     await newUser.save()

     return res.status(200).json({msg:'sign up successfull'})

 }catch(error){
  return res.status(500).json({msg:'error while sign up'})
 }
}
export { signupUser };
